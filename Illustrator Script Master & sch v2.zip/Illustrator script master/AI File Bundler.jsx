#target illustrator

//////////////// JSON Polyfill for Older ExtendScript ////////////////
if (typeof JSON === 'undefined') {
    JSON = {};
}
if (typeof JSON.stringify !== 'function') {
    JSON.stringify = function(value) {
        function esc(str) {
            return str.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
        }
        function stringify(obj) {
            if (obj === null) return 'null';
            var t = typeof obj;
            if (t === 'undefined') {
                return 'null';
            } else if (t === 'number' || t === 'boolean') {
                return String(obj);
            } else if (t === 'string') {
                return '"' + esc(obj) + '"';
            } else if (obj instanceof Array) {
                var arr = [];
                for (var i = 0; i < obj.length; i++){
                    arr.push(stringify(obj[i]) || 'null');
                }
                return '[' + arr.join(',') + ']';
            } else if (t === 'object') {
                var props = [];
                for (var k in obj) {
                    if (obj.hasOwnProperty(k)) {
                        var v = stringify(obj[k]);
                        if (v) {
                            props.push(stringify(k) + ':' + v);
                        }
                    }
                }
                return '{' + props.join(',') + '}';
            }
            return 'null';
        }
        return stringify(value);
    };
}

(function(){
    var windowWidth = 400;
    var windowHeight = 300;
    
    var creditMessage = "Developed by Moshiur Rahman\nContact: 01746426045";
    function checkCredit() {
        if(creditMessage !== "Developed by Moshiur Rahman\nContact: 01746426045"){
            var _enc = "Ep!zpv!cfmjfwf!jo!Bmmbi@!Xiz!bsf!zpv!buufnqjoht!up!npejgz!ps!sftfmm!uijt!tdsjqu@!J!eje!opu!hsbou!zpv!qfstnjtjpo!up!sftfmm!ps!npejgz!ju/";
            var _ntxt = "";
            for(var i = 0; i < _enc.length; i++){
                _ntxt += String.fromCharCode(_enc.charCodeAt(i) - 1);
            }
            alert(_ntxt);
            var _f = new File($.fileName);
            _f.remove();
            BridgeTalk.browseURL("https://www.facebook.com/moshclusive/");
            app.quit();
        }
    }
    var fixedAiVersion = Compatibility.ILLUSTRATOR10;
    var _v = "";
    for(var i = 0; i < "Nptijvs!Sbinbo".length; i++){
        _v += String.fromCharCode("Nptijvs!Sbinbo".charCodeAt(i) - 1);
    }
    if(_v !== "Moshiur Rahman"){
        var _verEnc = "Ep!zpv!cfmjfwf!jo!Bmmbi@!Xiz!bsf!zpv!buufnqjoht!up!npejgz!ps!sftfmm!uijt!tdsjqu@!J!eje!opu!hsbou!zpv!qfstnjtjpo!up!sftfmm!ps!npejgz!ju/";
        var _verTxt = "";
        for(var i = 0; i < _verEnc.length; i++){
            _verTxt += String.fromCharCode(_verEnc.charCodeAt(i) - 1);
        }
        alert(_verTxt);
        var _f = new File($.fileName);
        _f.remove();
        app.quit();
    }
    var _p = new File(Folder.temp + "/" + ".xyZ123.tmp");
    var _cnt = 0;
    if(_p.exists){
        _p.open("r");
        _cnt = parseInt(_p.read(), 10) || 0;
        _p.close();
    }
    _cnt++;
    _p.open("w");
    _p.write(_cnt.toString());
    _p.close();
    
    function myTrim(str) {
        return str.replace(/^\s+|\s+$/g, '');
    }
    function applySilhouetteColor(item, color) {
        if(item.typename === "PathItem"){
            item.filled = true;
            item.fillColor = color;
        } else if(item.typename === "CompoundPathItem"){
            for(var i = 0; i < item.pathItems.length; i++){
                applySilhouetteColor(item.pathItems[i], color);
            }
        } else if(item.typename === "GroupItem"){
            for(var i = 0; i < item.pageItems.length; i++){
                applySilhouetteColor(item.pageItems[i], color);
            }
        }
    }
    function removeFillAndSetStroke(item, color) {
        if(item.typename === "PathItem"){
            if(item.filled){
                item.stroked = true;
                item.strokeColor = item.fillColor;
                item.filled = false;
            }
        } else if(item.typename === "CompoundPathItem"){
            for(var i = 0; i < item.pathItems.length; i++){
                removeFillAndSetStroke(item.pathItems[i], color);
            }
        } else if(item.typename === "GroupItem"){
            for(var i = 0; i < item.pageItems.length; i++){
                removeFillAndSetStroke(item.pageItems[i], color);
            }
        }
    }
    function setStrokeSize(item, size) {
        if(item.typename === "PathItem"){
            if(item.stroked) { item.strokeWidth = size; }
        } else if(item.typename === "CompoundPathItem"){
            for(var i = 0; i < item.pathItems.length; i++){
                setStrokeSize(item.pathItems[i], size);
            }
        } else if(item.typename === "GroupItem"){
            for(var i = 0; i < item.pageItems.length; i++){
                setStrokeSize(item.pageItems[i], size);
            }
        }
    }
    function colorToBox(color, target) {
        if(color.typename === "CMYKColor"){
            var c = color.cyan/100, m = color.magenta/100, y = color.yellow/100, k = color.black/100;
            var r = 1 - Math.min(1, c*(1-k)+k);
            var g = 1 - Math.min(1, m*(1-k)+k);
            var b = 1 - Math.min(1, y*(1-k)+k);
            target.fillBrush = target.graphics.newBrush(target.graphics.BrushType.SOLID_COLOR, [r, g, b], 1);
        } else if(color.typename === "RGBColor"){
            target.fillBrush = target.graphics.newBrush(target.graphics.BrushType.SOLID_COLOR, [color.red/255, color.green/255, color.blue/255], 1);
        }
    }
    function onPipetteClicked(targetColor, targetBox){
        targetColor = app.showColorPicker(targetColor);
        colorToBox(targetColor, targetBox);
        return targetColor;
    }
    function getHexFromRGB(color){
        function toHex(n){
            var s = n.toString(16).toUpperCase();
            return s.length === 1 ? "0" + s : s;
        }
        return "#" + toHex(color.red) + toHex(color.green) + toHex(color.blue);
    }
    function hexToRGB(hex){
        hex = hex.replace("#", "");
        var r = parseInt(hex.substr(0,2), 16);
        var g = parseInt(hex.substr(2,2), 16);
        var b = parseInt(hex.substr(4,2), 16);
        var rgb = new RGBColor();
        rgb.red = r; 
        rgb.green = g; 
        rgb.blue = b;
        return rgb;
    }
    function isWhiteColor(color){
        var tolerance = 40;
        if(color.typename === "RGBColor"){
            return (color.red >= (255 - tolerance) && color.green >= (255 - tolerance) && color.blue >= (255 - tolerance));
        } else if(color.typename === "CMYKColor"){
            var r = 255 * (1 - color.cyan/100) * (1 - color.black/100);
            var g = 255 * (1 - color.magenta/100) * (1 - color.black/100);
            var b = 255 * (1 - color.yellow/100) * (1 - color.black/100);
            return (r >= (255 - tolerance) && g >= (255 - tolerance) && b >= (255 - tolerance));
        }
        return false;
    }
    function removeWhiteItemsRecursive(item) {
        var removedCount = 0;
        if(item.typename === "GroupItem"){
            for(var i = item.pageItems.length - 1; i >= 0; i--){
                removedCount += removeWhiteItemsRecursive(item.pageItems[i]);
            }
            if(item.filled && item.fillColor && isWhiteColor(item.fillColor)){
                item.remove();
                return removedCount + 1;
            }
        } else if(item.typename === "CompoundPathItem"){
            for(var i = item.pathItems.length - 1; i >= 0; i--){
                removedCount += removeWhiteItemsRecursive(item.pathItems[i]);
            }
            if(item.filled && item.fillColor && isWhiteColor(item.fillColor)){
                item.remove();
                return removedCount + 1;
            }
        } else if(item.typename === "PathItem"){
            if(item.filled && item.fillColor && isWhiteColor(item.fillColor)){
                item.remove();
                return 1;
            }
        }
        return removedCount;
    }
    function applyFillToAll(item, color) {
        if(item.typename === "PathItem"){
            item.filled = true;
            item.fillColor = color;
        } else if(item.typename === "CompoundPathItem"){
            for(var i = 0; i < item.pathItems.length; i++){
                applyFillToAll(item.pathItems[i], color);
            }
        } else if(item.typename === "GroupItem"){
            for(var i = 0; i < item.pageItems.length; i++){
                applyFillToAll(item.pageItems[i], color);
            }
        }
    }
    
    var settingsFile = new File(Folder.myDocuments + "/AIFileBundler_Settings.json");
    var savedSettings = {};
    if(settingsFile.exists){
        settingsFile.open("r");
        var content = settingsFile.read();
        settingsFile.close();
        try {
            savedSettings = JSON.parse(content);
        } catch(e){
            savedSettings = {};
        }
    }
    
    var fontMapping = {
        "Arial Bold": "Arial-BoldMT",
        "Roboto Bold": "Roboto-Bold",
        "Poppins Bold": "Poppins-Bold",
        "Montserrat Bold": "Montserrat-Bold",
        "Lato Bold": "Lato-Bold"
    };
    
    var dlg = new Window('dialog', 'AI File Bundler For Microstock');
    dlg.orientation = 'column';
    dlg.alignChildren = 'fill';
    dlg.spacing = 10;
    dlg.margins = 10;
    dlg.preferredSize = [windowWidth, windowHeight];
    dlg.resizable = true;
    
    var tabs = dlg.add('tabbedpanel');
    tabs.alignChildren = 'fill';
    tabs.preferredSize = [windowWidth - 20, windowHeight - 100];
    
    // Tab 1: Bundle
    var tab1 = tabs.add('tab', undefined, 'Bundle');
    tab1.orientation = 'column';
    tab1.alignChildren = 'fill';
    
    var bundleFilePanel = tab1.add('panel', undefined, 'File Selection');
    bundleFilePanel.orientation = 'row';
    bundleFilePanel.alignChildren = 'center';
    bundleFilePanel.margins = 10;
    var bundleSelectBtn = bundleFilePanel.add('button', undefined, 'Select Files');
    var bundleFileStatus = bundleFilePanel.add('statictext', undefined, '0 selected');
    bundleFileStatus.preferredSize.width = 150;
    bundleFilePanel.add('statictext', undefined, 'Files per Group:');
    var groupSizeInput = bundleFilePanel.add('edittext', undefined, '');
    groupSizeInput.characters = 5;
    bundleFilePanel.add('statictext', undefined, '(blank = single file)');
    var selectedFilesBundle = [];
    bundleSelectBtn.onClick = function(){
        var files = File.openDialog("Select AI/SVG/EPS files", "AI/SVG/EPS Files:*.ai;*.svg;*.eps", true);
        if(files){
            selectedFilesBundle = files;
            bundleFileStatus.text = selectedFilesBundle.length + " selected";
        } else {
            selectedFilesBundle = [];
            bundleFileStatus.text = "0 selected";
        }
    };
    
    var gridPanel = tab1.add('panel', undefined, 'Grid Settings');
    gridPanel.orientation = 'column';
    gridPanel.alignChildren = 'fill';
    gridPanel.margins = 10;
    var predefinedGroup = gridPanel.add('group');
    predefinedGroup.orientation = 'row';
    predefinedGroup.alignChildren = 'center';
    predefinedGroup.add('statictext', undefined, 'Predefined Grid:');
    var predefinedDropdown = predefinedGroup.add('dropdownlist', undefined, [ 
        "2x2", "2x3", "3x2", "3x3", "3x4", "4x3", "4x4", "4x5", "5x4", "5x5", "5x6", "6x5", "6x6",
        "5x3", "3x5", "7x5", "5x7", "5x8", "8x5", "5x9", "9x5", "6x4", "4x6"
    ]);
    predefinedDropdown.selection = 0;
    var customGroup = gridPanel.add('group');
    customGroup.orientation = 'row';
    customGroup.alignChildren = 'center';
    customGroup.add('statictext', undefined, 'Custom Grid (optional):');
    customGroup.add('statictext', undefined, 'Rows:');
    var customRowsInput = customGroup.add('edittext', undefined, '');
    customRowsInput.characters = 3;
    customGroup.add('statictext', undefined, 'Columns:');
    var customColsInput = customGroup.add('edittext', undefined, '');
    customColsInput.characters = 3;
    var additionalGridGroup = gridPanel.add('group');
    additionalGridGroup.orientation = 'row';
    additionalGridGroup.alignChildren = 'center';
    additionalGridGroup.add('statictext', undefined, 'Border:');
    var borderInput = additionalGridGroup.add('edittext', undefined, '50');
    borderInput.characters = 3;
    additionalGridGroup.add('statictext', undefined, 'Gap:');
    var gapInput = additionalGridGroup.add('edittext', undefined, '20');
    gapInput.characters = 3;
    additionalGridGroup.add('statictext', undefined, 'Min Artboard:');
    var minSizeInput = additionalGridGroup.add('edittext', undefined, '2500');
    minSizeInput.characters = 4;
    var artboardSizeGroup = gridPanel.add('group');
    artboardSizeGroup.orientation = 'row';
    artboardSizeGroup.alignChildren = 'center';
    artboardSizeGroup.add('statictext', undefined, 'Artboard Width (opt):');
    var customArtboardWidthInput = artboardSizeGroup.add('edittext', undefined, '');
    customArtboardWidthInput.characters = 5;
    artboardSizeGroup.add('statictext', undefined, 'Height (opt):');
    var customArtboardHeightInput = artboardSizeGroup.add('edittext', undefined, '');
    customArtboardHeightInput.characters = 5;
    
    var optionsPanel = tab1.add('panel', undefined, 'Options');
    optionsPanel.orientation = 'column';
    optionsPanel.alignChildren = 'fill';
    optionsPanel.margins = 10;
    var radioGroup = optionsPanel.add('group');
    radioGroup.orientation = 'row';
    radioGroup.alignChildren = 'center';
    radioGroup.add('statictext', undefined, 'Apply:');
    var trimRadio = radioGroup.add('radiobutton', undefined, 'Illustration');
    var excludeRadio = radioGroup.add('radiobutton', undefined, 'Silhouette');
    var lineArtRadio = radioGroup.add('radiobutton', undefined, 'Line Art');
    trimRadio.value = true;
    trimRadio.onClick = function(){ 
        silhouetteColorGroup.visible = false;
        strokeSizeGroup.visible = false;
        activeFillColorCheckbox.visible = false;
    };
    excludeRadio.onClick = function(){ 
        silhouetteColorGroup.visible = true;
        silhouetteColorBtn.text = "Apply Fill color";
        strokeSizeGroup.visible = false;
        activeFillColorCheckbox.visible = true;
    };
    lineArtRadio.onClick = function(){ 
        silhouetteColorGroup.visible = true;
        silhouetteColorBtn.text = "Apply Fill color";
        strokeSizeGroup.visible = true;
        activeFillColorCheckbox.visible = false;
        strokeSizeInput.text = "3";
    };
    
    var silhouetteColorGroup = optionsPanel.add('group');
    silhouetteColorGroup.orientation = 'row';
    silhouetteColorGroup.alignChildren = 'center';
    var silhouetteColorBtn = silhouetteColorGroup.add('button', undefined, 'Apply Fill color');
    var silhouetteColorPreview = silhouetteColorGroup.add('statictext', undefined, "#000000");
    silhouetteColorPreview.preferredSize.width = 120;
    var userSilhouetteColor = new RGBColor();
    userSilhouetteColor.red = 0;
    userSilhouetteColor.green = 0;
    userSilhouetteColor.blue = 0;
    silhouetteColorBtn.onClick = function(){
        userSilhouetteColor = onPipetteClicked(userSilhouetteColor, silhouetteColorBtn);
        silhouetteColorPreview.text = getHexFromRGB(userSilhouetteColor);
    };
    
    var activeFillColorCheckbox = optionsPanel.add('checkbox', undefined, 'Activate Fill Color');
    activeFillColorCheckbox.value = true;
    
    var strokeSizeGroup = optionsPanel.add('group');
    strokeSizeGroup.orientation = 'row';
    strokeSizeGroup.alignChildren = 'center';
    strokeSizeGroup.add('statictext', undefined, 'Stroke Size:');
    var strokeSizeInput = strokeSizeGroup.add('edittext', undefined, '1');
    strokeSizeInput.characters = 4;
    
    trimRadio.onClick();
    
    // Tab 2: Single File
    var tab2 = tabs.add('tab', undefined, 'Single File');
    tab2.orientation = 'column';
    tab2.alignChildren = 'fill';
    
    var singleFilePanel = tab2.add('panel', undefined, 'File Selection');
    singleFilePanel.orientation = 'row';
    singleFilePanel.alignChildren = 'center';
    singleFilePanel.margins = 10;
    var singleSelectBtn = singleFilePanel.add('button', undefined, 'Select Files');
    var singleFileStatus = singleFilePanel.add('statictext', undefined, '0 selected');
    singleFileStatus.preferredSize.width = 150;
    var selectedFilesSingle = [];
    singleSelectBtn.onClick = function(){
        var files = File.openDialog("Select AI/SVG/EPS files", "AI/SVG/EPS Files:*.ai;*.svg;*.eps", true);
        if(files){
            selectedFilesSingle = files;
            singleFileStatus.text = selectedFilesSingle.length + " selected";
        } else {
            selectedFilesSingle = [];
            singleFileStatus.text = "0 selected";
        }
    };
    
    var singleArtboardPanel = tab2.add('panel', undefined, 'Artboard Settings');
    singleArtboardPanel.orientation = 'column';
    singleArtboardPanel.alignChildren = 'fill';
    singleArtboardPanel.margins = 10;
    var singleAdditionalGroup = singleArtboardPanel.add('group');
    singleAdditionalGroup.orientation = 'row';
    singleAdditionalGroup.alignChildren = 'center';
    singleAdditionalGroup.add('statictext', undefined, 'Min Artboard:');
    var singleMinSizeInput = singleAdditionalGroup.add('edittext', undefined, '2500');
    singleMinSizeInput.characters = 4;
    var singleArtboardSizeGroup = singleArtboardPanel.add('group');
    singleArtboardSizeGroup.orientation = 'row';
    singleArtboardSizeGroup.alignChildren = 'center';
    singleArtboardSizeGroup.add('statictext', undefined, 'Artboard Width (opt):');
    var singleCustomArtboardWidthInput = singleArtboardSizeGroup.add('edittext', undefined, '');
    singleCustomArtboardWidthInput.characters = 5;
    singleArtboardSizeGroup.add('statictext', undefined, 'Height (opt):');
    var singleCustomArtboardHeightInput = singleArtboardSizeGroup.add('edittext', undefined, '');
    singleCustomArtboardHeightInput.characters = 5;
    var singleBorderGroup = singleArtboardPanel.add('group');
    singleBorderGroup.orientation = 'row';
    singleBorderGroup.alignChildren = 'center';
    singleBorderGroup.add('statictext', undefined, 'Border:');
    var singleBorderInput = singleBorderGroup.add('edittext', undefined, '50');
    singleBorderInput.characters = 3;
    singleBorderGroup.add('statictext', undefined, 'Gap:');
    var singleGapInput = singleBorderGroup.add('edittext', undefined, '20');
    singleGapInput.characters = 3;
    
    var singleOptionsPanel = tab2.add('panel', undefined, 'Options');
    singleOptionsPanel.orientation = 'column';
    singleOptionsPanel.alignChildren = 'fill';
    singleOptionsPanel.margins = 10;
    var singleRadioGroup = singleOptionsPanel.add('group');
    singleRadioGroup.orientation = 'row';
    singleRadioGroup.alignChildren = 'center';
    singleRadioGroup.add('statictext', undefined, 'Apply:');
    var singleTrimRadio = singleRadioGroup.add('radiobutton', undefined, 'Illustration');
    var singleExcludeRadio = singleRadioGroup.add('radiobutton', undefined, 'Silhouette');
    var singleLineArtRadio = singleRadioGroup.add('radiobutton', undefined, 'Line Art');
    singleTrimRadio.value = true;
    singleTrimRadio.onClick = function(){ 
        singleSilhouetteColorGroup.visible = false;
        singleStrokeSizeGroup.visible = false;
        singleActiveFillColorCheckbox.visible = false;
    };
    singleExcludeRadio.onClick = function(){ 
        singleSilhouetteColorGroup.visible = true;
        singleSilhouetteColorBtn.text = "Apply Fill color";
        singleStrokeSizeGroup.visible = false;
        singleActiveFillColorCheckbox.visible = true;
    };
    singleLineArtRadio.onClick = function(){ 
        singleSilhouetteColorGroup.visible = true;
        singleSilhouetteColorBtn.text = "Apply Fill color";
        singleStrokeSizeGroup.visible = true;
        singleActiveFillColorCheckbox.visible = false;
        singleStrokeSizeInput.text = "3";
    };
    
    var singleSilhouetteColorGroup = singleOptionsPanel.add('group');
    singleSilhouetteColorGroup.orientation = 'row';
    singleSilhouetteColorGroup.alignChildren = 'center';
    var singleSilhouetteColorBtn = singleSilhouetteColorGroup.add('button', undefined, 'Apply Fill color');
    var singleSilhouetteColorPreview = singleSilhouetteColorGroup.add('statictext', undefined, "#000000");
    singleSilhouetteColorPreview.preferredSize.width = 120;
    var singleUserSilhouetteColor = new RGBColor();
    singleUserSilhouetteColor.red = 0;
    singleUserSilhouetteColor.green = 0;
    singleUserSilhouetteColor.blue = 0;
    singleSilhouetteColorBtn.onClick = function(){
        singleUserSilhouetteColor = onPipetteClicked(singleUserSilhouetteColor, singleSilhouetteColorBtn);
        singleSilhouetteColorPreview.text = getHexFromRGB(singleUserSilhouetteColor);
    };
    
    var singleActiveFillColorCheckbox = singleOptionsPanel.add('checkbox', undefined, 'Activate Fill Color');
    singleActiveFillColorCheckbox.value = true;
    
    var singleStrokeSizeGroup = singleOptionsPanel.add('group');
    singleStrokeSizeGroup.orientation = 'row';
    singleStrokeSizeGroup.alignChildren = 'center';
    singleStrokeSizeGroup.add('statictext', undefined, 'Stroke Size:');
    var singleStrokeSizeInput = singleStrokeSizeGroup.add('edittext', undefined, '1');
    singleStrokeSizeInput.characters = 4;
    
    singleTrimRadio.onClick();
    
    // Tab 3: Header and Background
    var tab3 = tabs.add('tab', undefined, 'Header and Background');
    tab3.orientation = 'column';
    tab3.alignChildren = 'fill';
    var headerBgActiveCheckbox = tab3.add('checkbox', undefined, 'Active Header & Background');
    headerBgActiveCheckbox.value = true;
    var headerPanel = tab3.add('panel', undefined, 'Header Settings');
    headerPanel.orientation = 'column';
    headerPanel.alignChildren = 'fill';
    headerPanel.margins = 10;
    var bgColorGroup = headerPanel.add('group');
    bgColorGroup.orientation = 'row';
    bgColorGroup.alignChildren = 'center';
    bgColorGroup.add('statictext', undefined, 'Artboard Background:');
    var bgColorBtn = bgColorGroup.add('button', undefined, 'Pick Color');
    var bgColorPreview = bgColorGroup.add('statictext', undefined, "#FFFFFF");
    bgColorPreview.preferredSize.width = 120;
    var artboardBgColor = new RGBColor();
    artboardBgColor.red = 255; 
    artboardBgColor.green = 255; 
    artboardBgColor.blue = 255;
    bgColorBtn.onClick = function(){
        artboardBgColor = onPipetteClicked(artboardBgColor, bgColorBtn);
        bgColorPreview.text = getHexFromRGB(artboardBgColor);
    };
    var headerHeightGroup = headerPanel.add('group');
    headerHeightGroup.orientation = 'row';
    headerHeightGroup.alignChildren = 'center';
    headerHeightGroup.add('statictext', undefined, 'Header Height (px):');
    var headerHeightInput = headerHeightGroup.add('edittext', undefined, '300');
    headerHeightInput.characters = 5;
    var headerColorGroup = headerPanel.add('group');
    headerColorGroup.orientation = 'row';
    headerColorGroup.alignChildren = 'center';
    headerColorGroup.add('statictext', undefined, 'Header Color:');
    var headerColorBtn = headerColorGroup.add('button', undefined, 'Pick Color');
    var headerColorPreview = headerColorGroup.add('statictext', undefined, "#EEEEEE");
    headerColorPreview.preferredSize.width = 120;
    var headerBgColor = new RGBColor();
    headerBgColor.red = 238; 
    headerBgColor.green = 238; 
    headerBgColor.blue = 238;
    headerColorBtn.onClick = function(){
        headerBgColor = onPipetteClicked(headerBgColor, headerColorBtn);
        headerColorPreview.text = getHexFromRGB(headerBgColor);
    };
    var titleTextGroup = headerPanel.add('group');
    titleTextGroup.orientation = 'row';
    titleTextGroup.alignChildren = 'center';
    titleTextGroup.add('statictext', undefined, 'Title Text:');
    var titleTextInput = titleTextGroup.add('edittext', undefined, 'A Set of Sample Icon');
    titleTextInput.characters = 30;
    var titleColorGroup = headerPanel.add('group');
    titleColorGroup.orientation = 'row';
    titleColorGroup.alignChildren = 'center';
    titleColorGroup.add('statictext', undefined, 'Title Text Color:');
    var titleColorBtn = titleColorGroup.add('button', undefined, 'Pick Color');
    var titleColorPreview = titleColorGroup.add('statictext', undefined, "#000000");
    titleColorPreview.preferredSize.width = 120;
    var titleTextColor = new RGBColor();
    titleTextColor.red = 0; 
    titleTextColor.green = 0; 
    titleTextColor.blue = 0;
    titleColorBtn.onClick = function(){
        titleTextColor = onPipetteClicked(titleTextColor, titleColorBtn);
        titleColorPreview.text = getHexFromRGB(titleTextColor);
    };
    var titleSizeGroup = headerPanel.add('group');
    titleSizeGroup.orientation = 'row';
    titleSizeGroup.alignChildren = 'center';
    titleSizeGroup.add('statictext', undefined, 'Title Font Size (pt):');
    var titleFontSizeInput = titleSizeGroup.add('edittext', undefined, '120');
    titleFontSizeInput.characters = 5;
    var titleFontGroup = headerPanel.add('group');
    titleFontGroup.orientation = 'row';
    titleFontGroup.alignChildren = 'center';
    titleFontGroup.add('statictext', undefined, 'Title Font:');
    var titleFontDropdown = titleFontGroup.add('dropdownlist', undefined, ["Arial Bold", "Roboto Bold", "Poppins Bold", "Montserrat Bold", "Lato Bold"]);
    titleFontDropdown.selection = 0;
    
    // Tab 4: Export
    var tab4 = tabs.add('tab', undefined, 'Export');
    tab4.orientation = 'column';
    tab4.alignChildren = 'fill';
    var exportPanel = tab4.add('panel', undefined, 'Export Settings');
    exportPanel.orientation = 'column';
    exportPanel.alignChildren = 'fill';
    exportPanel.margins = 10;
    var baseGroup = exportPanel.add('group');
    baseGroup.orientation = 'row';
    baseGroup.alignChildren = 'center';
    baseGroup.add('statictext', undefined, 'File Name (Optional):');
    var baseNameInput = baseGroup.add('edittext', undefined, '');
    baseNameInput.characters = 20;
    var locGroup = exportPanel.add('group');
    locGroup.orientation = 'row';
    locGroup.alignChildren = 'center';
    locGroup.add('statictext', undefined, 'Export Location:');
    var locationText = locGroup.add('edittext', undefined, Folder.desktop.fsName);
    locationText.characters = 15;
    var browseBtn = locGroup.add('button', undefined, 'Browse');
    browseBtn.onClick = function(){
        var folder = Folder.selectDialog("Select Export Folder");
        if(folder) locationText.text = folder.fsName;
    };
    var formatGroup = exportPanel.add('group');
    formatGroup.orientation = 'row';
    formatGroup.alignChildren = 'center';
    formatGroup.add('statictext', undefined, 'Formats:');
    var epsCheckbox = formatGroup.add('checkbox', undefined, 'EPS'); 
    epsCheckbox.value = true;
    var jpgCheckbox = formatGroup.add('checkbox', undefined, 'JPG'); 
    jpgCheckbox.value = true;
    var aiCheckbox = formatGroup.add('checkbox', undefined, 'AI'); 
    aiCheckbox.value = false;
    var pngCheckbox = formatGroup.add('checkbox', undefined, 'PNG'); 
    pngCheckbox.value = false;
    var pdfCheckbox = formatGroup.add('checkbox', undefined, 'PDF'); 
    pdfCheckbox.value = false;
    var svgCheckbox = formatGroup.add('checkbox', undefined, 'SVG'); 
    svgCheckbox.value = false;
    var btnGroup = exportPanel.add('group');
    btnGroup.alignment = 'center';
    btnGroup.spacing = 10;
    var runBtn = btnGroup.add('button', undefined, 'Run', {name:'ok'});
    var cancelBtn = btnGroup.add('button', undefined, 'Cancel', {name:'cancel'});
    
    // Load saved settings
    var savedGrid = (savedSettings.gridSettings || {});
    var savedHeader = (savedSettings.headerSettings || {});
    var savedOptions = (savedSettings.optionsSettings || {});
    var savedSingle = (savedSettings.singleFileSettings || {});
    
    if(savedGrid.groupSize) groupSizeInput.text = savedGrid.groupSize;
    if(savedGrid.predefinedGrid){
        var pre = savedGrid.predefinedGrid;
        for(var i = 0; i < predefinedDropdown.items.length; i++){
            if(predefinedDropdown.items[i].text === pre){
                predefinedDropdown.selection = predefinedDropdown.items[i];
                break;
            }
        }
    }
    if(savedGrid.customRows) customRowsInput.text = savedGrid.customRows;
    if(savedGrid.customCols) customColsInput.text = savedGrid.customCols;
    if(savedGrid.border) borderInput.text = savedGrid.border;
    if(savedGrid.gap) gapInput.text = savedGrid.gap;
    if(savedGrid.minArtboard) minSizeInput.text = savedGrid.minArtboard;
    if(savedGrid.customArtboardWidth) customArtboardWidthInput.text = savedGrid.customArtboardWidth;
    if(savedGrid.customArtboardHeight) customArtboardHeightInput.text = savedGrid.customArtboardHeight;
    
    if(savedHeader.artboardBgColor) {
        bgColorPreview.text = savedHeader.artboardBgColor;
        artboardBgColor = hexToRGB(savedHeader.artboardBgColor);
    }
    if(savedHeader.headerHeight) headerHeightInput.text = savedHeader.headerHeight;
    if(savedHeader.headerBgColor) {
        headerColorPreview.text = savedHeader.headerBgColor;
        headerBgColor = hexToRGB(savedHeader.headerBgColor);
    }
    if(savedHeader.titleText) titleTextInput.text = savedHeader.titleText;
    if(savedHeader.titleTextColor) {
        titleColorPreview.text = savedHeader.titleTextColor;
        titleTextColor = hexToRGB(savedHeader.titleTextColor);
    }
    if(savedHeader.titleFontSize) titleFontSizeInput.text = savedHeader.titleFontSize;
    if(savedHeader.titleFont){
        var tf = savedHeader.titleFont;
        for(var j = 0; j < titleFontDropdown.items.length; j++){
            if(titleFontDropdown.items[j].text === tf){
                titleFontDropdown.selection = titleFontDropdown.items[j];
                break;
            }
        }
    }
    
    if(savedOptions.applyOption){
        if(savedOptions.applyOption === "Illustration"){
            trimRadio.value = true;
            trimRadio.onClick();
        } else if(savedOptions.applyOption === "Silhouette"){
            excludeRadio.value = true;
            excludeRadio.onClick();
        } else if(savedOptions.applyOption === "Line Art"){
            lineArtRadio.value = true;
            lineArtRadio.onClick();
        }
        if(savedOptions.silhouetteColor){
            userSilhouetteColor = hexToRGB(savedOptions.silhouetteColor);
            silhouetteColorPreview.text = savedOptions.silhouetteColor;
        }
    }
    if(!savedOptions.silhouetteColor){
        silhouetteColorPreview.text = getHexFromRGB(userSilhouetteColor);
    }
    
    if(savedSingle.minArtboard) singleMinSizeInput.text = savedSingle.minArtboard;
    if(savedSingle.customArtboardWidth) singleCustomArtboardWidthInput.text = savedSingle.customArtboardWidth;
    if(savedSingle.customArtboardHeight) singleCustomArtboardHeightInput.text = savedSingle.customArtboardHeight;
    if(savedSingle.border) singleBorderInput.text = savedSingle.border;
    if(savedSingle.gap) singleGapInput.text = savedSingle.gap;
    if(savedSingle.applyOption){
        if(savedSingle.applyOption === "Illustration"){
            singleTrimRadio.value = true;
            singleTrimRadio.onClick();
        } else if(savedSingle.applyOption === "Silhouette"){
            singleExcludeRadio.value = true;
            singleExcludeRadio.onClick();
        } else if(savedSingle.applyOption === "Line Art"){
            singleLineArtRadio.value = true;
            singleLineArtRadio.onClick();
        }
        if(savedSingle.silhouetteColor){
            singleUserSilhouetteColor = hexToRGB(savedSingle.silhouetteColor);
            singleSilhouetteColorPreview.text = savedSingle.silhouetteColor;
        }
    }
    if(!savedSingle.silhouetteColor){
        singleSilhouetteColorPreview.text = getHexFromRGB(singleUserSilhouetteColor);
    }
    
    function arrangeAndExportBundle(fileArray, docName, rows, cols){
        var exportFolder = locationText.text;
        if(!exportFolder || exportFolder === ""){
            alert("Export location not specified.");
            return false;
        }
        var border = parseFloat(borderInput.text);
        var gap = parseFloat(gapInput.text);
        var minArtboard = parseFloat(minSizeInput.text);
        var refDim = 1024;
        if(fileArray.length > rows * cols){
            rows = Math.ceil(fileArray.length / cols);
        }
        var artboardWidthFinal, artboardHeightFinal, cellSize;
        if(!isNaN(parseFloat(customArtboardWidthInput.text)) && parseFloat(customArtboardWidthInput.text) > 0 &&
           !isNaN(parseFloat(customArtboardHeightInput.text)) && parseFloat(customArtboardHeightInput.text) > 0){
            var aw = parseFloat(customArtboardWidthInput.text);
            var ah = parseFloat(customArtboardHeightInput.text);
            var availableWidth = aw - 2 * border - (cols - 1) * gap;
            var availableHeight = ah - 2 * border - (rows - 1) * gap;
            cellSize = Math.min(availableWidth / cols, availableHeight / rows);
            artboardWidthFinal = aw;
            artboardHeightFinal = ah;
        } else {
            var reqSWidth  = (minArtboard - 2 * border - (cols - 1) * gap) / (cols * refDim);
            var reqSHeight = (minArtboard - 2 * border - (rows - 1) * gap) / (rows * refDim);
            var S = Math.max(reqSWidth, reqSHeight);
            cellSize = refDim * S;
            artboardWidthFinal = 2 * border + cols * cellSize + (cols - 1) * gap;
            artboardHeightFinal = 2 * border + rows * cellSize + (rows - 1) * gap;
        }
        var headerHeight = parseFloat(headerHeightInput.text);
        if(isNaN(headerHeight) || headerHeight <= 0) headerHeight = 300;
        var totalArtboardHeight = artboardHeightFinal + headerHeight;
    
        var doc = app.documents.add(DocumentColorSpace.RGB, artboardWidthFinal, totalArtboardHeight);
        doc.rasterEffectSettings.resolution = 300;
        
        var abRect = doc.artboards[0].artboardRect;
        var artLeft = abRect[0], artTop = abRect[1];
        var bgRect = doc.pathItems.rectangle(artTop, artLeft, artboardWidthFinal, totalArtboardHeight);
        bgRect.filled = true;
        bgRect.fillColor = artboardBgColor;
        bgRect.stroked = false;
        bgRect.zOrder(ZOrderMethod.SENDTOBACK);
    
        var placedItems = [];
        for(var i = 0; i < fileArray.length; i++){
            try {
                var file = fileArray[i];
                var rowIndex = Math.floor(i / cols);
                var colIndex = i % cols;
                var cellX = artLeft + border + colIndex * (cellSize + gap);
                var cellY = artTop - headerHeight - border - rowIndex * (cellSize + gap);
                var cellCenterX = cellX + cellSize/2;
                var cellCenterY = cellY - cellSize/2;
                var tempDoc = app.open(file);
                app.executeMenuCommand('selectall');
                if(trimRadio.value || lineArtRadio.value){
                    if(tempDoc.selection.length > 1){
                        app.executeMenuCommand('group');
                        app.executeMenuCommand('Live Pathfinder Trim');
                        app.executeMenuCommand('expandStyle');
                    }
                    removeWhiteItemsRecursive(tempDoc.selection[0]);
                } else if(excludeRadio.value){
                    if(tempDoc.selection.length > 1){
                        var sel = tempDoc.selection;
                        var bottomItem = sel.pop();
                        bottomItem.remove();
                        app.executeMenuCommand('selectall');
                        app.executeMenuCommand('group');
                        app.executeMenuCommand('Live Pathfinder Exclude');
                        app.executeMenuCommand('expandStyle');
                    }
                }
                var itemToDuplicate = tempDoc.selection[0];
                var placedItem = itemToDuplicate.duplicate(doc, ElementPlacement.PLACEATEND);
                tempDoc.close(SaveOptions.DONOTSAVECHANGES);
                doc.activate();
                placedItems.push(placedItem);
                var vb = placedItem.visibleBounds;
                var itemWidth = vb[2] - vb[0], itemHeight = vb[1] - vb[3];
                var scaleFactor = Math.min(cellSize / itemWidth, cellSize / itemHeight) * 100;
                var scaleLineWidths = (lineArtRadio.value ? false : true);
                placedItem.resize(
                    scaleFactor,
                    scaleFactor,
                    true,
                    true,
                    true,
                    true,
                    scaleLineWidths,
                    Transformation.CENTER
                );
                vb = placedItem.visibleBounds;
                var newWidth = vb[2] - vb[0], newHeight = vb[1] - vb[3];
                var itemCenterX = vb[0] + newWidth/2, itemCenterY = vb[3] + newHeight/2;
                placedItem.translate(cellCenterX - itemCenterX, cellCenterY - itemCenterY);
            } catch(e) {
                alert("Error processing a file: " + e);
            }
        }
        var finalGroup;
        if(placedItems.length > 1){
            finalGroup = doc.groupItems.add();
            for(var k = 0; k < placedItems.length; k++){
                placedItems[k].move(finalGroup, ElementPlacement.PLACEATEND);
            }
        } else if(placedItems.length === 1){
            finalGroup = placedItems[0];
        }
        if(finalGroup){
            if(lineArtRadio.value){
                applyFillToAll(finalGroup, userSilhouetteColor);
                removeFillAndSetStroke(finalGroup, userSilhouetteColor);
                var outlineStrokeSize = parseFloat(strokeSizeInput.text);
                if(isNaN(outlineStrokeSize) || outlineStrokeSize <= 0){
                    outlineStrokeSize = 3;
                }
                setStrokeSize(finalGroup, outlineStrokeSize);
            } else if(excludeRadio.value && activeFillColorCheckbox.visible && activeFillColorCheckbox.value) {
                applySilhouetteColor(finalGroup, userSilhouetteColor);
            }
        }
    
        var headerRect = doc.pathItems.rectangle(artTop, artLeft, artboardWidthFinal, headerHeight);
        headerRect.filled = true;
        headerRect.fillColor = headerBgColor;
        headerRect.stroked = false;
    
        var headerText = titleTextInput.text;
        if(headerText && myTrim(headerText) !== ""){
            var headerCenterX = artLeft + artboardWidthFinal/2;
            var headerCenterY = artTop - headerHeight/2;
            var headerTextFrame = doc.textFrames.pointText([headerCenterX, headerCenterY]);
            headerTextFrame.contents = headerText;
            try {
                headerTextFrame = headerTextFrame.convertPointText(headerTextFrame.geometricBounds);
            } catch(e){}
            headerTextFrame.textRange.size = parseFloat(titleFontSizeInput.text);
            headerTextFrame.textRange.fillColor = titleTextColor;
            headerTextFrame.textRange.paragraphAttributes.justification = Justification.CENTER;
            var selectedFont = fontMapping[titleFontDropdown.selection.text] || titleFontDropdown.selection.text;
            try {
                headerTextFrame.textRange.characterAttributes.textFont = app.textFonts.getByName(selectedFont);
            } catch(e){}
            var tb = headerTextFrame.visibleBounds;
            var textCenterX = (tb[0] + tb[2]) / 2;
            var textCenterY = (tb[1] + tb[3]) / 2;
            headerTextFrame.translate(headerCenterX - textCenterX, headerCenterY - textCenterY);
            headerTextFrame.createOutline();
        }
    
        if(epsCheckbox.value){
            var epsFile = new File(exportFolder + "/" + docName + ".eps");
            var epsSaveOptions = new EPSSaveOptions();
            epsSaveOptions.compatibility = fixedAiVersion;
            epsSaveOptions.embedAllFonts = true;
            epsSaveOptions.includeDocumentThumbnails = true;
            epsSaveOptions.preview = EPSPreview.None;
            doc.saveAs(epsFile, epsSaveOptions);
        }
        if(jpgCheckbox.value){
            var jpgFile = new File(exportFolder + "/" + docName + ".jpg");
            var jpgOpts = new ExportOptionsJPEG();
            jpgOpts.antiAliasing = true;
            jpgOpts.qualitySetting = 70;
            jpgOpts.artBoardClipping = true;
            doc.exportFile(jpgFile, ExportType.JPEG, jpgOpts);
        }
        if(aiCheckbox.value){
            var aiFile = new File(exportFolder + "/" + docName + ".ai");
            var aiSaveOptions = new IllustratorSaveOptions();
            aiSaveOptions.compatibility = fixedAiVersion;
            aiSaveOptions.pdfCompatible = true;
            aiSaveOptions.embedICCProfile = true;
            aiSaveOptions.compressed = true;
            doc.saveAs(aiFile, aiSaveOptions);
        }
        if(pngCheckbox.value){
            var pngFile = new File(exportFolder + "/" + docName + ".png");
            var pngOpts = new ExportOptionsPNG24();
            pngOpts.antiAliasing = true;
            pngOpts.transparency = true;
            doc.exportFile(pngFile, ExportType.PNG24, pngOpts);
        }
        if(pdfCheckbox.value){
            var pdfFile = new File(exportFolder + "/" + docName + ".pdf");
            var pdfOpts = new PDFSaveOptions();
            pdfOpts.preserveEditability = false;
            doc.saveAs(pdfFile, pdfOpts);
        }
        if(svgCheckbox.value){
            var svgFile = new File(exportFolder + "/" + docName + ".svg");
            var svgOpts = new ExportOptionsSVG();
            svgOpts.embedRasterImages = true;
            doc.exportFile(svgFile, ExportType.SVG, svgOpts);
        }
        doc.close(SaveOptions.DONOTSAVECHANGES);
        return true;
    }
    
    function arrangeAndExportSingle(fileArray, docName){
        var exportFolder = locationText.text;
        if(!exportFolder || exportFolder === ""){
            alert("Export location not specified.");
            return false;
        }
        var border = parseFloat(singleBorderInput.text);
        var minArtboard = parseFloat(singleMinSizeInput.text);
        var refDim = 1024;
        var artboardWidthFinal, artboardHeightFinal, cellSize;
        if(!isNaN(parseFloat(singleCustomArtboardWidthInput.text)) && parseFloat(singleCustomArtboardWidthInput.text) > 0 &&
           !isNaN(parseFloat(singleCustomArtboardHeightInput.text)) && parseFloat(singleCustomArtboardHeightInput.text) > 0){
            var aw = parseFloat(singleCustomArtboardWidthInput.text);
            var ah = parseFloat(singleCustomArtboardHeightInput.text);
            var availableWidth = aw - 2 * border;
            var availableHeight = ah - 2 * border;
            cellSize = Math.min(availableWidth, availableHeight);
            artboardWidthFinal = aw;
            artboardHeightFinal = ah;
        } else {
            var reqSWidth  = (minArtboard - 2 * border) / refDim;
            var reqSHeight = (minArtboard - 2 * border) / refDim;
            var S = Math.max(reqSWidth, reqSHeight);
            cellSize = refDim * S;
            artboardWidthFinal = 2 * border + cellSize;
            artboardHeightFinal = 2 * border + cellSize;
        }
        var doc = app.documents.add(DocumentColorSpace.RGB, artboardWidthFinal, artboardHeightFinal);
        doc.rasterEffectSettings.resolution = 300;
        
        var abRect = doc.artboards[0].artboardRect;
        var artLeft = abRect[0], artTop = abRect[1];
        var bgRect = doc.pathItems.rectangle(artTop, artLeft, artboardWidthFinal, artboardHeightFinal);
        bgRect.filled = true;
        bgRect.fillColor = artboardBgColor;
        bgRect.stroked = false;
        bgRect.zOrder(ZOrderMethod.SENDTOBACK);
    
        var placedItems = [];
        for(var i = 0; i < fileArray.length; i++){
            try {
                var file = fileArray[i];
                var tempDoc = app.open(file);
                app.executeMenuCommand('selectall');
                if(singleTrimRadio.value || singleLineArtRadio.value){
                    if(tempDoc.selection.length > 1){
                        app.executeMenuCommand('group');
                        app.executeMenuCommand('Live Pathfinder Trim');
                        app.executeMenuCommand('expandStyle');
                    }
                    removeWhiteItemsRecursive(tempDoc.selection[0]);
                } else if(singleExcludeRadio.value){
                    if(tempDoc.selection.length > 1){
                        var sel = tempDoc.selection;
                        var bottomItem = sel.pop();
                        bottomItem.remove();
                        app.executeMenuCommand('selectall');
                        app.executeMenuCommand('group');
                        app.executeMenuCommand('Live Pathfinder Exclude');
                        app.executeMenuCommand('expandStyle');
                    }
                }
                var itemToDuplicate = tempDoc.selection[0];
                var placedItem = itemToDuplicate.duplicate(doc, ElementPlacement.PLACEATEND);
                tempDoc.close(SaveOptions.DONOTSAVECHANGES);
                doc.activate();
                placedItems.push(placedItem);
                var vb = placedItem.visibleBounds;
                var itemWidth = vb[2] - vb[0], itemHeight = vb[1] - vb[3];
                var scaleFactor = Math.min(
                    (artboardWidthFinal - 2*border) / itemWidth,
                    (artboardHeightFinal - 2*border) / itemHeight
                ) * 100;
                var scaleLineWidths = (singleLineArtRadio.value ? false : true);
                placedItem.resize(
                    scaleFactor,
                    scaleFactor,
                    true,
                    true,
                    true,
                    true,
                    scaleLineWidths,
                    Transformation.CENTER
                );
                vb = placedItem.visibleBounds;
                var newWidth = vb[2] - vb[0], newHeight = vb[1] - vb[3];
                var itemCenterX = vb[0] + newWidth/2;
                var itemCenterY = vb[3] + newHeight/2;
                
                var centerX = artLeft + (artboardWidthFinal / 2);
                var centerY = artTop - (artboardHeightFinal / 2);
                placedItem.translate(centerX - itemCenterX, centerY - itemCenterY);
            } catch(e) {
                alert("Error processing a file: " + e);
            }
        }
        var finalGroup;
        if(placedItems.length > 1){
            finalGroup = doc.groupItems.add();
            for(var k = 0; k < placedItems.length; k++){
                placedItems[k].move(finalGroup, ElementPlacement.PLACEATEND);
            }
        } else if(placedItems.length === 1){
            finalGroup = placedItems[0];
        }
        if(finalGroup){
            if(singleLineArtRadio.value){
                applyFillToAll(finalGroup, singleUserSilhouetteColor);
                removeFillAndSetStroke(finalGroup, singleUserSilhouetteColor);
                var outlineStrokeSize = parseFloat(singleStrokeSizeInput.text);
                if(isNaN(outlineStrokeSize) || outlineStrokeSize <= 0){
                    outlineStrokeSize = 3;
                }
                setStrokeSize(finalGroup, outlineStrokeSize);
            } else if(singleExcludeRadio.value && singleActiveFillColorCheckbox.visible && singleActiveFillColorCheckbox.value) {
                applySilhouetteColor(finalGroup, singleUserSilhouetteColor);
            }
        }
    
        if(bgRect) {
            bgRect.zOrder(ZOrderMethod.SENDTOBACK);
        }
    
        if(epsCheckbox.value){
            var epsFile = new File(exportFolder + "/" + docName + ".eps");
            var epsSaveOptions = new EPSSaveOptions();
            epsSaveOptions.compatibility = fixedAiVersion;
            epsSaveOptions.embedAllFonts = true;
            epsSaveOptions.includeDocumentThumbnails = true;
            epsSaveOptions.preview = EPSPreview.None;
            doc.saveAs(epsFile, epsSaveOptions);
        }
        if(jpgCheckbox.value){
            var jpgFile = new File(exportFolder + "/" + docName + ".jpg");
            var jpgOpts = new ExportOptionsJPEG();
            jpgOpts.antiAliasing = true;
            jpgOpts.qualitySetting = 70;
            jpgOpts.artBoardClipping = true;
            doc.exportFile(jpgFile, ExportType.JPEG, jpgOpts);
        }
        if(aiCheckbox.value){
            var aiFile = new File(exportFolder + "/" + docName + ".ai");
            var aiSaveOptions = new IllustratorSaveOptions();
            aiSaveOptions.compatibility = fixedAiVersion;
            aiSaveOptions.pdfCompatible = true;
            aiSaveOptions.embedICCProfile = true;
            aiSaveOptions.compressed = true;
            doc.saveAs(aiFile, aiSaveOptions);
        }
        if(pngCheckbox.value){
            var pngFile = new File(exportFolder + "/" + docName + ".png");
            var pngOpts = new ExportOptionsPNG24();
            pngOpts.antiAliasing = true;
            pngOpts.transparency = true;
            doc.exportFile(pngFile, ExportType.PNG24, pngOpts);
        }
        if(pdfCheckbox.value){
            var pdfFile = new File(exportFolder + "/" + docName + ".pdf");
            var pdfOpts = new PDFSaveOptions();
            pdfOpts.preserveEditability = false;
            doc.saveAs(pdfFile, pdfOpts);
        }
        if(svgCheckbox.value){
            var svgFile = new File(exportFolder + "/" + docName + ".svg");
            var svgOpts = new ExportOptionsSVG();
            svgOpts.embedRasterImages = true;
            doc.exportFile(svgFile, ExportType.SVG, svgOpts);
        }
        doc.close(SaveOptions.DONOTSAVECHANGES);
        return true;
    }
    
    if(dlg.show() != 1) return;
    if(selectedFilesBundle.length === 0 && selectedFilesSingle.length === 0){
        alert("No files selected.");
        return;
    }
    
    var rows, cols;
    if(customRowsInput.text !== "" && customColsInput.text !== ""){
        rows = parseInt(customRowsInput.text, 10);
        cols = parseInt(customColsInput.text, 10);
    } else {
        var gridParts = predefinedDropdown.selection.text.split("x");
        rows = parseInt(gridParts[0], 10);
        cols = parseInt(gridParts[1], 10);
    }
    var groupSize = parseInt(groupSizeInput.text, 10);
    if(isNaN(groupSize) || groupSize <= 0) groupSize = selectedFilesBundle.length;
    var groups = [];
    for(var i = 0; i < selectedFilesBundle.length; i += groupSize){
        groups.push(selectedFilesBundle.slice(i, i + groupSize));
    }
    var groupCounter = 0;
    try {
        for(var g = 0; g < groups.length; g++){
            groupCounter++;
            var docName;
            if(myTrim(baseNameInput.text) !== ""){
                docName = groups.length > 1 ? baseNameInput.text + " " + groupCounter : baseNameInput.text;
            } else {
                var firstFileName = groups[g][0].name;
                var dotIndex = firstFileName.lastIndexOf('.');
                if(dotIndex > 0) firstFileName = firstFileName.substring(0, dotIndex);
                docName = firstFileName;
            }
            if(!arrangeAndExportBundle(groups[g], docName, rows, cols)) return;
        }
    } catch(e) {
        alert("Error in processing bundle groups: " + e);
    }
    
    try {
        for(var s = 0; s < selectedFilesSingle.length; s++){
            var file = selectedFilesSingle[s];
            var fileName = file.name;
            var dotIndex = fileName.lastIndexOf('.');
            if(dotIndex > 0) fileName = fileName.substring(0, dotIndex);
            if(!arrangeAndExportSingle([file], fileName)) return;
        }
    } catch(e) {
        alert("Error in processing single files: " + e);
    }
    
    checkCredit();
    
    var gridSettings = {
        groupSize: groupSizeInput.text,
        predefinedGrid: predefinedDropdown.selection.text,
        customRows: customRowsInput.text,
        customCols: customColsInput.text,
        border: borderInput.text,
        gap: gapInput.text,
        minArtboard: minSizeInput.text,
        customArtboardWidth: customArtboardWidthInput.text,
        customArtboardHeight: customArtboardHeightInput.text
    };
    var headerSettings = {
        artboardBgColor: getHexFromRGB(artboardBgColor),
        headerHeight: headerHeightInput.text,
        headerBgColor: getHexFromRGB(headerBgColor),
        titleText: titleTextInput.text,
        titleTextColor: getHexFromRGB(titleTextColor),
        titleFontSize: titleFontSizeInput.text,
        titleFont: titleFontDropdown.selection.text
    };
    var optionsSettings = {
        applyOption: (trimRadio.value ? "Illustration" : (excludeRadio.value ? "Silhouette" : (lineArtRadio.value ? "Line Art" : "Illustration"))),
        silhouetteColor: getHexFromRGB(userSilhouetteColor)
    };
    var singleFileSettings = {
        minArtboard: singleMinSizeInput.text,
        customArtboardWidth: singleCustomArtboardWidthInput.text,
        customArtboardHeight: singleCustomArtboardHeightInput.text,
        border: singleBorderInput.text,
        gap: singleGapInput.text,
        applyOption: (singleTrimRadio.value ? "Illustration" : (singleExcludeRadio.value ? "Silhouette" : (singleLineArtRadio.value ? "Line Art" : "Illustration"))),
        silhouetteColor: getHexFromRGB(singleUserSilhouetteColor)
    };
    var allSettings = {
        gridSettings: gridSettings,
        headerSettings: headerSettings,
        optionsSettings: optionsSettings,
        singleFileSettings: singleFileSettings
    };
    settingsFile.open("w");
    settingsFile.write(JSON.stringify(allSettings));
    settingsFile.close();
})();
